const nodemailer = require("nodemailer");

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { to, subject, text, companyType } = body;

  if (!to || !subject || !text) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing fields" }) };
  }

  const transporter = nodemailer.createTransport({
    host: "smtp.ionos.de",
    port: 587,
    secure: false,
    requireTLS: true,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  try {
    await transporter.sendMail({
      from: '"Striker Energy" <info@striker-energy.de>',
      to: to,
      subject: subject,
      text: text,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Email sent" }),
    };
  } catch (err) {
    console.error("Email error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to send email", detail: err.message }),
    };
  }
};
